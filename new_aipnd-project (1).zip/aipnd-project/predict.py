import matplotlib.pyplot as plot
import numpy
import torch
from torch import nn
from torch import tensor
from torch import optim
import torch.nn.functional as fun
from torch.autograd import Variable
from torchvision import datasets, transforms
import torchvision.models as torch_models
from collections import OrderedDict
import json
import PIL
from PIL import Image
import argparse

import base

#Command Line Arguments

args_parse = argparse.ArgumentParser(
    description='current_image_prediction-file')
args_parse.add_argument('input_img', default='paind-project/flowers/test/1/image_06752.jpg', nargs='*', action="store", type = str)
args_parse.add_argument('net_checkpoint', default='/home/workspace/paind-project/net_checkpoint.pth', nargs='*', action="store",type = str)
args_parse.add_argument('nettop_k', default=5, dest="nettop_k", action="store", type=int)
args_parse.add_argument('category_names', dest="category_names", action="store", default='cat_to_name.json')
args_parse.add_argument('cpu', default="cpu", action="store", dest="cpu")

p_args = args_parse.parse_args()
path_image = p_args.input_img
number_of_outputs = p_args.nettop_k
net_power = p_args.cpu
input_img = p_args.input_img
user_path = p_args.net_checkpoint



training_loader, testing_loader, validation_loader = base.l_data()


base.checkpoint_loader(user_path)


with open('cat_to_name.json', 'r') as json_file:
    cat_to_name = json.load(json_file)


prediction_probabilities = base.current_image_prediction(path_image, net_model, number_of_outputs, net_power)


prediction_labels = [cat_to_name[str(index + 1)] for index in numpy.array(prediction_probabilities[1][0])]
current_torch_probability = numpy.array(prediction_probabilities[0][0])


i=0
while i < number_of_outputs:
    print("{} current_torch_probability of {}".format(prediction_labels[i], current_torch_probability[i]))
    i += 1
    #everything is all set
