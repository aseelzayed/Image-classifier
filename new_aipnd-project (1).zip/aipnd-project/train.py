import matplotlib.pyplot as plot
import numpy
import time
import torch
from torch import nn
from torch import tensor
from torch import optim
import torch.nn.functional as fun
from torch.autograd import Variable
from torchvision import datasets, transforms
import torchvision.models as torch_models
import argparse

import base

args_parse = argparse.ArgumentParser(description='train.py')
# CLI ARGS

args_parse.add_argument('data_dir', nargs='*', action="store", default="./flowers/")
args_parse.add_argument('cpu', dest="cpu", action="store", default="cpu")
args_parse.add_argument('output_dir', dest="output_dir", action="store", default="./net_checkpoint.pth")
args_parse.add_argument('adaptablility', dest="adaptablility", action="store", default=0.001)
args_parse.add_argument('net_checkout', dest = "net_checkout", action = "store", default = 0.5)
args_parse.add_argument('number_of_epochs', dest="number_of_epochs", action="store", type=int, default=1)
args_parse.add_argument('architecture', dest="architecture", action="store", default="vgg16", type = str)
args_parse.add_argument('hidden_units', type=int, dest="hidden_units", action="store", default=120)

p_args = args_parse.parse_args()
location = p_args.data_dir
user_path = p_args.output_dir
l_r = p_args.adaptablility
path_structure = p_args.architecture
net_checkout = p_args.net_checkout
masked_layer1 = p_args.hidden_units
net_power = p_args.cpu
number_of_epochs = p_args.number_of_epochs


tloader, v_loader, tst_loader = base.l_data(location)


net_model, net_optimization, net_criteria = base.setup_network(path_structure,net_checkout,masked_layer1,l_r,net_power)


base.network_trainer(net_model, net_optimization, net_criteria, number_of_epochs, 20, tloader, net_power)


base.checkpoint_registration(user_path,path_structure,masked_layer1,net_checkout,l_r)

#The Model has finished its training
