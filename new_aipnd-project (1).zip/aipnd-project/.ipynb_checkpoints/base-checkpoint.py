#add all imports here
import torchvision.models as models
#%matplotlib inline
#%config InlineBackend.figure_format = ‘retina’import matplotlib.pyplot as pltimport torch
from torchvision import datasets, transforms
import helper
import json

#call a pretrained model
from model import *

data_dir = 'flowers'
train_dir = data_dir + '/train'
valid_dir = data_dir + '/valid'
test_dir = data_dir + '/test'

# TODO: Load the datasets with ImageFolder
dataset = datasets.ImageFolder(data_dir, transform=transform)

# TODO: Define your transforms for the training, validation, and testing sets
transform = transforms.Compose([transforms.Resize(224),
                                transforms.CenterCrop(224),
                                transforms.ToTensor()])
# TODO: Using the image datasets and the trainforms, define the dataloaders
dataloader = torch.utils.data.DataLoader(dataset, batch_size=32, shuffle=True)

images, labels = next(iter(dataloader))
helper.imshow(images[0], normalize=False)

#use the json module to load in a mapping from category label to category name
with open('cat_to_name.json', 'r') as f:
    cat_to_name = json.load(f)

#add image transformation
train_transforms = transforms.Compose([
                                transforms.RandomRotation(30),
                                transforms.RandomResizedCrop(224),
                                transforms.RandomHorizontalFlip(),
                                transforms.ToTensor()])

test_transforms = transforms.Compose([transforms.Resize(255),
                                      transforms.CenterCrop(224),
                                      transforms.ToTensor()])
train_data = datasets.ImageFolder(data_dir + 'train.py',  
                                    transform=train_transforms)                                       
test_data = datasets.ImageFolder(data_dir + 'test.py', 
                                    transform=test_transforms)

#Data Loading
trainloader = torch.utils.data.DataLoader(train_data,
                                                   batch_size=32)
testloader = torch.utils.data.DataLoader(test_data, batch_size=32)

