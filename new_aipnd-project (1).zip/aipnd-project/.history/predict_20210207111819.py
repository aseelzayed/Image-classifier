from base import *

#set the model in evaluation mode
model.eval()

#create a function for image processing to input into our model
#open the image and resize it, but keep the aspect ratio to, final cropping is 224x224px

# Process our image
def process_image(image_path):