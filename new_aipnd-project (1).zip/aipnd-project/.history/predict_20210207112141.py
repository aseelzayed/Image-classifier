from base import *

#set the model in evaluation mode
model.eval()

#create a function for image processing to input into our model
#open the image and resize it, but keep the aspect ratio to, final cropping is 224x224px

# Process our image
def process_image(image_path):
    # Load Image
    img = Image.open(image_path)
    # Get the dimensions of the image
    width, height = img.size
    # Resize by keeping the aspect ratio, but changing the dimension
    img = img.resize((224, int(224*(height/width))) if width < height else (int(224*(width/height)), 224))
    # Get the dimensions of the new image size
    width, height = img.size
    # Set the coordinates to do a center crop of 224 x 224
    left = (width - 224)/2
    top = (height - 224)/2
    
