from base import *

#set the model in evaluation mode
model.eval()

