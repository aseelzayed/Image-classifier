from base import *

#set the model in evaluation mode
model.eval()

#create a function for image processing to input into our model
#open the image and resize it, but keep the aspect ratio to, final cropping is 224x224px

# Process our image
def process_image(image_path):
    # Load Image
    img = Image.open(image_path)
    # Get the dimensions of the image
    width, height = img.size
    # Resize by keeping the aspect ratio, but changing the dimension
    img = img.resize((224, int(224*(height/width))) if width < height else (int(224*(width/height)), 224))
    # Get the dimensions of the new image size
    width, height = img.size
    # Set the coordinates to do a center crop of 224 x 224
    left = (width - 224)/2
    top = (height - 224)/2
    right = (width + 224)/2
    bottom = (height + 224)/2
    img = img.crop((left, top, right, bottom))
    # Turn image into numpy array
    img = np.array(img)
    # Make the color channel dimension first instead of last
    img = img.transpose((2, 0, 1))
    # Make all values between 0 and 1
    img = img/255
    # Normalize based on the preset mean and standard deviation
    img[0] = (img[0] - 0.485)/0.229
    img[1] = (img[1] - 0.456)/0.224
    img[2] = (img[2] - 0.406)/0.225
    # Add a fourth dimension to the beginning to indicate batch size
    img = img[np.newaxis,:]

    # Turn into a torch tensor
    image = torch.from_numpy(img)
    image = image.float()
    return image

#make preditions using our model
def predict(image, model):
    # Pass the image through our model
    output = model.forward(image)
    # Reverse the log function in our output
    output = torch.exp(output)
    # Get the top predicted class, and the output percentage for that class
    probs, classes = output.topk(1, dim=1)
    return probs.item(), classes.item()

#show our image
def show_image(image):
    # Convert image to numpy
    image = image.numpy()
    # Un-normalize the image
    image[0] = image[0] * 0.226 + 0.445

    # Print the image
    fig = plt.figure(figsize=(25, 4))
    plt.imshow(np.transpose(image[0], (1, 2, 0)))

#now let's se if our prediction actually works
image = process_image("root/image1234.jpg")
# Give image to model to predict output
top_prob, top_class = predict(image, model)
# Show the image
# Print the results
