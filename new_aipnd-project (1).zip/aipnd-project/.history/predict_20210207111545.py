from base import *

#set the model in evaluatin 
model.eval()

