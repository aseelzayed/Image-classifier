import matplotlib.pyplot as plot
import numpy
import torch
from torch import nn
from torch import tensor
from torch import optim
import torch.nn.functional as fun
from torch.autograd import Variable
from torchvision import datasets, transforms
import torchvision.models as torch_models
from collections import OrderedDict
import json
import PIL
from PIL import Image
import argparse
import os

user_path = os.getcwd()

data_dir = os.user_path.join(user_path,'flowers')
train_dir = os.user_path.join(data_dir,'train')
valid_dir = os.user_path.join(data_dir,'valid')
test_dir = os.user_path.join(data_dir,'test')

def l_data(location  = data_dir ):
    
    data_dir = location
    train_dir = os.user_path.join(data_dir,'train')
    valid_dir = os.user_path.join(data_dir,'valid')
    test_dir = os.user_path.join(data_dir,'test')

    t_transforms = transforms.Compose([transforms.RandomRotation(50),transforms.RandomResizedCrop(224),transforms.RandomHorizontalFlip(),transforms.ToTensor(),transforms.Normalize([0.485, 0.456, 0.406],[0.229, 0.224, 0.225])])

    tst_transforms = transforms.Compose([transforms.Resize(256),transforms.CenterCrop(224),transforms.ToTensor(),transforms.Normalize([0.485, 0.456, 0.406],[0.229, 0.224, 0.225])])

    valid_transforms = transforms.Compose([transforms.Resize(256),transforms.CenterCrop(224),transforms.ToTensor(),transforms.Normalize([0.485, 0.456, 0.406],[0.229, 0.224, 0.225])])


    # TODO: Load 
    train_data = datasets.ImageFolder(train_dir, transform=t_transforms)
    validation_data = datasets.ImageFolder(valid_dir, transform=valid_transforms)
    test_data = datasets.ImageFolder(test_dir ,transform = tst_transforms)

    # TODO:define the dataloaders
    tloader = torch.utils.data.DataLoader(train_data, batch_size=64, shuffle=True)
    v_loader = torch.utils.data.DataLoader(validation_data, batch_size =32,shuffle = True)
    tst_loader = torch.utils.data.DataLoader(test_data, batch_size = 20, shuffle = True)



    return tloader , v_loader, tst_loader


def setup_network(path_structure='densenet121',net_checkout=0.5, masked_layer1 = 120,l_r = 0.001,net_power=0):
   
    net_model = torch_models.densenet121(pretrained=True)
    
    for param in net_model.parameters():
        param.requires_grad = False

        from collections import OrderedDict
        classifier = nn.Sequential(OrderedDict([
            ('net_checkout',nn.Dropout(net_checkout)),
            ('Inputs', nn.Linear(arch['path_structure'], masked_layer1)),
            ('Relu1', nn.ReLU()),
            ('masked_layer1', nn.Linear(masked_layer1, 90)),
            ('Relu2',nn.ReLU()),
            ('hidden_layer2',nn.Linear(90,80)),
            ('Relu3',nn.ReLU()),
            ('hidden_layer3',nn.Linear(80,102)),
            ('current_torch_output', nn.LogSoftmax(dim=1))
                          ]))


        net_model.classifier = classifier
        net_criteria = nn.NLLLoss()
        net_optimization = optim.Adam(net_model.classifier.parameters(), l_r )

        return net_model, net_criteria, net_optimization


def network_trainer(net_model, net_criteria, net_optimization, number_of_epochs = 3, net_print=20, net_loader=tloader, net_power='cpu'):

    net_steps = 0
    net_running_loss = 0

    print("starting network training")
    for e in range(number_of_epochs):
        net_running_loss = 0
        for loop_count, (inputs, labels) in enumerate(net_loader):
            net_steps += 1
                            
            net_optimization.zero_grad()

            # Forward and backward passes
            net_outputs = net_model.forward(inputs)
            net_loss = net_criteria(net_outputs, labels)
            net_loss.backward()
            net_optimization.step()

            net_running_loss += net_loss.item()

            if net_steps % net_print == 0:
                net_model.eval()
                net_vlost = 0
                net_accuracy=0


                for loop_count, (inputs2,labels2) in enumerate(v_loader):
                    net_optimization.zero_grad()
                   
                    with torch.no_grad():
                        net_outputs = net_model.forward(inputs2)
                        net_vlost = net_criteria(net_outputs,labels2)
                        ps = torch.exp(net_outputs).data
                        equality = (labels2.data == ps.max(1)[1])
                        net_accuracy += equality.type_as(torch.FloatTensor()).mean()

                net_vlost = net_vlost / len(v_loader)
                net_accuracy = net_accuracy /len(v_loader)



                print("net_epoch: {}/{}... ".format(e+1, number_of_epochs),
                      "Net_Loss: {:.6f}".format(net_running_loss/net_print),
                      "Net_Validation _ost {:.3f}".format(net_vlost),
                       "Net_Accuracy: {:.5f}".format(net_accuracy))


                net_running_loss = 0

def checkpoint_registration(user_path='net_checkpoint.pth',path_structure ='densenet121', masked_layer1=120,net_checkout=0.5,l_r=0.001,number_of_epochs=12):
    
    #save the net_model at a specified by the user user_path

    
    net_model.class_to_idx = train_data.class_to_idx
    net_model.cpu
    torch.save({'path_structure' :path_structure,
                'masked_layer1':masked_layer1,
                'net_checkout':net_checkout,
                'l_r':l_r,
                'nb_of_epochs':number_of_epochs,
                'State_dict':net_model.state_dict(),
                'Class_to_idx':net_model.class_to_idx},
                user_path)


def checkpoint_loader(user_path='net_checkpoint.pth'):
    
    #return the neural network

    net_checkpoint = torch.load(user_path)
    path_structure = net_checkpoint['path_structure']
    masked_layer1 = net_checkpoint['masked_layer1']
    net_checkout = net_checkpoint['net_checkout']
    l_r=net_checkpoint['l_r']

    net_model,_,_ = setup_network(path_structure , net_checkout,masked_layer1,l_r)

    net_model.class_to_idx = net_checkpoint['Class_to_idx']
    net_model.load_state_dict(net_checkpoint['State_dict'])


def image_processor(current_image_path):
    
    for i in current_image_path:
        user_path = str(i)
    current_img = Image.open(i) 

    remake_image = transforms.Compose([
        transforms.Resize(224),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])

    current_tensor_image = remake_image(current_img)

    return current_tensor_image


def current_image_prediction(current_image_path, net_model, net_torch_topk=5,net_power='cpu'):
    
    current_torch_image = image_processor(current_image_path)
    current_torch_image = current_torch_image.unsqueeze_(0)
    current_torch_image = current_torch_image.float()

    with torch.no_grad():
        current_torch_output=net_model.forward(current_torch_image)

    current_torch_probability = fun.softmax(current_torch_output.data,dim=1)

    return current_torch_probability.net_torch_topk(net_torch_topk)
